package com.example.lms.student;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.course.Course;
import com.example.lms.course.CourseRepository;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	private StudentRepository studentRepo;
	private CourseRepository courseRepo;
	
	@Autowired
	StudentController(StudentRepository studentRepo, CourseRepository courseRepo){
		this.studentRepo = studentRepo;
		this.courseRepo = courseRepo;
	}
	
	@GetMapping(value="/courses/available")
	public List<Course> getAvailableCourses(HttpServletRequest req){
		Student session = (Student) req.getAttribute("student");
		return courseRepo.findByMajorAndSemester(session.getMajor(), session.getSemester());
	}
	
	@PostMapping(value="/courses")
	public Student addRegisteredCourse(HttpServletRequest req, @RequestBody Course course) {
		Student session = (Student) req.getAttribute("student");
		session.getCourses().add(course);
		return studentRepo.save(session);
	}
}
