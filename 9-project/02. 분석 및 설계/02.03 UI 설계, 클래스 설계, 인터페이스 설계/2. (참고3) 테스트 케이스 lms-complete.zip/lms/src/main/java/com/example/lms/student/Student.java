package com.example.lms.student;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.example.lms.course.Course;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data @NoArgsConstructor @AllArgsConstructor @Builder 
public class Student {
	@Id
	private int id;
	private String name;
	private String major;
	private int semester;
	
	@OneToMany
	private List<Course> courses;
}
