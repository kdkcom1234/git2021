package com.example.lms.course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.student.StudentRepository;

@RestController
@RequestMapping("/courses")
public class CourseController {
	
	private CourseRepository repo;
	
	@Autowired
	CourseController(CourseRepository repo){
		this.repo = repo;
	}	

	@GetMapping(value="/{id}")
	public Course getCourseDetail(@PathVariable int id){
		return repo.findById(id).orElse(null);
	}
}
