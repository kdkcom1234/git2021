package com.example.lms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;

import com.example.lms.course.Course;
import com.example.lms.course.CourseController;
import com.example.lms.course.CourseRepository;
import com.example.lms.student.Student;
import com.example.lms.student.StudentController;
import com.example.lms.student.StudentRepository;

@SpringBootTest
class LmsApplicationTests {
	
	@Autowired StudentController studentController;
	@Autowired CourseController courseController;
	@Autowired CourseRepository courseRepo;
	@Autowired StudentRepository studentRepo;
	
	@BeforeEach
	void cleanTestdata() {
		studentRepo.deleteAll();
		courseRepo.deleteAll();	
	}
	
	/* 강의 수강 신청 */
	@Test
	void registerCourse() {
		/* ----- 1. given - 테스트 데이터 준비 ----- */
		// mock course list
		List<Course> mockCourses = new ArrayList<Course>();
		mockCourses.add(
				Course.builder()
				.id(1).name("test course 1")
				.major("CS").semester(1).build()
		);
		mockCourses.add(
				Course.builder()
				.id(2).name("test course 2")
				.major("CS").semester(1).build()
		);
		mockCourses.add(
				Course.builder()
				.id(3).name("test course 3")
				.major("CS").semester(2).build()
		);
		
		courseRepo.saveAll(mockCourses);

		// mock student
		Student mockStudent = Student.builder()
							.id(1)
							.name("test")
							.major("CS")
							.semester(1)
							.courses(new ArrayList<Course>())
							.build();
		studentRepo.save(mockStudent);
		
		HttpServletRequest mockReq = new MockHttpServletRequest();
		mockReq.setAttribute("student", mockStudent);
		
		/* ----- 2. when - 테스트 수행, 수강신청 가능한 목록 조회 ----- */
		List<Course> availableCourses = studentController.getAvailableCourses(mockReq);
		
		/* ----- 3. then - 실제 결과와 예상 결과 비교 ----- */
		assertEquals(2, availableCourses.size());
		assertEquals(mockCourses.get(0).getName(), availableCourses.get(0).getName());
		assertEquals(mockCourses.get(1).getName(), availableCourses.get(1).getName());
		
		
		/* ----- 2. when - 테스트 수행, 강의 상세 정보 조회 ----- */
		Course course = courseController.getCourseDetail(1);
		System.out.println(course);
		
		/* ----- 3. then - 실제 결과와 예상 결과 비교 ----- */
		assertEquals(mockCourses.get(0).getName(), course.getName());
		assertEquals(mockCourses.get(0).getMajor(), course.getMajor());
		assertEquals(mockCourses.get(0).getSemester(), course.getSemester());
		
		
		/* ----- 2. when - 테스트 수행, 수강신청 ----- */
		Student student = studentController.addRegisteredCourse(mockReq, mockCourses.get(0));
		
		/* ----- 3. then - 실제 결과와 예상 결과 비교 ----- */
		Course registeredCourse = student.getCourses().get(0);
		assertEquals(mockCourses.get(0).getName(), registeredCourse.getName());
		assertEquals(mockCourses.get(0).getMajor(), registeredCourse.getMajor());
		assertEquals(mockCourses.get(0).getSemester(), registeredCourse.getSemester());
	}
	

}
